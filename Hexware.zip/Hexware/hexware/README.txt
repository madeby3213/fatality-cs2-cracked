Hexware is a Roblox external made by 1 developer (me/made) which is still in it's development phase stau tuned for more updates.
Hope you enjoy using my product!